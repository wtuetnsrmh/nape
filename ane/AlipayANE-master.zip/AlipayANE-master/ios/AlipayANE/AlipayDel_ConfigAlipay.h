//
//  AlipayDel_ConfigAlipay.h
//  AlipayANE
//
//  Created by rect on 13-10-6.
//
//

#import "AlipayDel.h"

@interface AlipayDel ()

@end
