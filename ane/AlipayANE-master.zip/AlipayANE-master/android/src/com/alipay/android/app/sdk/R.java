package com.alipay.android.app.sdk;

public final class R
{
  public final class attr
  {
  }

  public final class color
  {
    public static final int TextColorBlack = 2131034112;
    public static final int TextColorGray = 2131034114;
    public static final int TextColorWhite = 2131034113;
    public static final int ToastBgColor = 2131034115;
    public static final int bgColor = 2131034120;
    public static final int btnColor = 2131034116;
    public static final int dialog_tiltle_blue = 2131034126;
    public static final int downLoadBackFocus = 2131034124;
    public static final int downLoadBackNomal = 2131034123;
    public static final int downLoadBackPressed = 2131034125;
    public static final int downLoadTextNomal = 2131034121;
    public static final int downLoadTextPressed = 2131034122;
    public static final int opaque_blue = 2131034127;
    public static final int secondbtntextColor = 2131034118;
    public static final int textColorforCheckBox = 2131034119;
    public static final int textColorforItemTitle = 2131034117;
  }

  public final class drawable
  {
    public static final int air_72px_mobile_eula = 2130837504;
    public static final int dialog_bg_click = 2130837505;
    public static final int dialog_bg_normal = 2130837506;
    public static final int dialog_button_colorlist = 2130837507;
    public static final int dialog_button_submit = 2130837508;
    public static final int dialog_cut_line = 2130837509;
    public static final int dialog_split_h = 2130837510;
    public static final int dialog_split_v = 2130837511;
    public static final int icon = 2130837512;
    public static final int mp_warning_32x32_n = 2130837513;
    public static final int popup_bg = 2130837514;
    public static final int refresh = 2130837515;
    public static final int refresh_button = 2130837516;
    public static final int refresh_push = 2130837517;
    public static final int title = 2130837518;
    public static final int title_background = 2130837519;
  }

  public final class id
  {
    public static final int AlipayTitle = 2131230722;
    public static final int CertificateDetails = 2131230750;
    public static final int Footer = 2131230749;
    public static final int Header = 2131230743;
    public static final int Line1 = 2131230748;
    public static final int Line2 = 2131230751;
    public static final int ROW1 = 2131230744;
    public static final int ROW2 = 2131230746;
    public static final int ServerName = 2131230747;
    public static final int TrustQuestion = 2131230752;
    public static final int WarningImage = 2131230745;
    public static final int btn_refresh = 2131230723;
    public static final int button_cancel = 2131230742;
    public static final int button_ok = 2131230741;
    public static final int dialog_button_group = 2131230728;
    public static final int dialog_content_view = 2131230727;
    public static final int dialog_divider = 2131230725;
    public static final int dialog_message = 2131230726;
    public static final int dialog_split_v = 2131230730;
    public static final int dialog_title = 2131230724;
    public static final int empty = 2131230740;
    public static final int file_save_button = 2131230737;
    public static final int file_save_label = 2131230736;
    public static final int file_save_name = 2131230738;
    public static final int file_save_panel = 2131230735;
    public static final int filecheck = 2131230734;
    public static final int filename = 2131230732;
    public static final int filepath = 2131230733;
    public static final int left_button = 2131230729;
    public static final int list = 2131230739;
    public static final int mainView = 2131230720;
    public static final int right_button = 2131230731;
    public static final int webView = 2131230721;
  }

  public final class layout
  {
    public static final int alipay = 2130903040;
    public static final int alipay_title = 2130903041;
    public static final int dialog_alert = 2130903042;
    public static final int expandable_chooser_row = 2130903043;
    public static final int expandable_multiple_chooser_row = 2130903044;
    public static final int main = 2130903045;
    public static final int multiple_file_selection_panel = 2130903046;
    public static final int ssl_certificate_warning = 2130903047;
  }

  public final class raw
  {
    public static final int debugger = 2130968576;
    public static final int debuginfo = 2130968577;
    public static final int mms_cfg = 2130968578;
    public static final int rgba8888 = 2130968579;
    public static final int ss_cfg = 2130968580;
    public static final int ss_sgn = 2130968581;
  }

  public final class string
  {
    public static final int IDA_APP_DEBUGGER_TIMEOUT_INFO = 2131099690;
    public static final int IDA_APP_UNABLE_LISTEN_ERROR = 2131099688;
    public static final int IDA_APP_WAITING_DEBUGGER_TITLE = 2131099687;
    public static final int IDA_APP_WAITING_DEBUGGER_WARNING = 2131099689;
    public static final int IDA_CERTIFICATE_DETAILS = 2131099686;
    public static final int IDA_CURL_INTERFACE_ALLSESS = 2131099680;
    public static final int IDA_CURL_INTERFACE_CERTIFICATE_DETAILS_TITLE = 2131099685;
    public static final int IDA_CURL_INTERFACE_CNAME_MSG = 2131099683;
    public static final int IDA_CURL_INTERFACE_NOSESS = 2131099677;
    public static final int IDA_CURL_INTERFACE_OK = 2131099678;
    public static final int IDA_CURL_INTERFACE_SERVER = 2131099681;
    public static final int IDA_CURL_INTERFACE_THISSESS = 2131099676;
    public static final int IDA_CURL_INTERFACE_TRUSTSER = 2131099682;
    public static final int IDA_CURL_INTERFACE_UNVERSER_2 = 2131099679;
    public static final int IDA_CURL_INTERFACE_VIEW_CERT = 2131099684;
    public static final int IDA_CURL_SSL_SECURITY_WARNING = 2131099675;
    public static final int app_name = 2131099674;
    public static final int app_version = 2131099691;
    public static final int audio_files = 2131099662;
    public static final int button_cancel = 2131099667;
    public static final int button_continue = 2131099668;
    public static final int button_exit = 2131099693;
    public static final int button_install = 2131099692;
    public static final int button_no = 2131099673;
    public static final int button_ok = 2131099666;
    public static final int button_yes = 2131099672;
    public static final int cancel = 2131099650;
    public static final int cancel_install_alipay = 2131099657;
    public static final int cancel_install_msp = 2131099656;
    public static final int confirm_title = 2131099648;
    public static final int content_description_icon = 2131099651;
    public static final int download = 2131099654;
    public static final int download_fail = 2131099655;
    public static final int empty_file_list = 2131099665;
    public static final int ensure = 2131099649;
    public static final int file_download = 2131099670;
    public static final int file_save_as = 2131099669;
    public static final int file_upload = 2131099671;
    public static final int flash_browser_plugin = 2131099661;
    public static final int image_files = 2131099663;
    public static final int install_alipay = 2131099660;
    public static final int install_msp = 2131099659;
    public static final int processing = 2131099653;
    public static final int redo = 2131099658;
    public static final int refresh = 2131099652;
    public static final int text_install_runtime = 2131099696;
    public static final int text_runtime_on_external_storage = 2131099697;
    public static final int text_runtime_required = 2131099695;
    public static final int title_adobe_air = 2131099694;
    public static final int video_files = 2131099664;
  }

  public final class style
  {
    public static final int AlertDialog = 2131165186;
    public static final int AppBaseTheme = 2131165184;
    public static final int AppTheme = 2131165185;
    public static final int Theme_NoShadow = 2131165187;
  }
}