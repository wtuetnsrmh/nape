﻿AlipayANE
=========

## 支付宝ANE  for IOS for android
包含以下内容：
* Alipay ANE for Android 安卓端ANE
* Alipay ANE for IOS 苹果移动端ANE
* IOS端url若要调用则需要修改-app.xml 在[iphone]标签中加入URL
* IOS端支付宝库请自行下载
* sample 对于android和IOS均适用 关于环境配置不在赘述

## 资源

* 官方SDK[Alipay](http://club.alipay.com/read-htm-tid-9976972.html) 

## 编译方法
* 查看Bulid文件夹下的Bulid ANE文件夹(ane.bat for win,ane.sh for mac)
* 查看Bulid文件夹下的Bulid APK文件夹

## 作者

* [platformANEs](https://github.com/platformanes)由 [zrong](http://zengrong.net) 和 [rect](http://www.shadowkong.com/) 共同发起并完成。
